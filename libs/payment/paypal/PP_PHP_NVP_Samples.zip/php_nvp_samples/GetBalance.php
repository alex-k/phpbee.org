
<!--

-->


<html >
<head>
    <title>PayPal PHP SDK - GetBalance API</title>
    <link href="sdk.css" rel="stylesheet" type="text/css" />
</head>
<body>
	<br>
	<center>
	<font size=2 color=black face=Verdana><b>GetBalance</b></font>
	<br><br>
    
	<form action="GetBalanceReceipt.php" method="post">
			<center><input type="Submit" value="Submit" /></center>
	</form>
    </center>
    <a class="home" id="CallsLink" href="index.html">Home</a>
</body>
</html>
